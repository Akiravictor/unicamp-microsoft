using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Class2

{
  public class Ex5
  {
    static public void run()
    {
      // Crie um programa paralelo que lê o arquivo transactions.txt,
      // executa as transações, e imprime os valores finais corretamente.
      // Para garantir o funcionamento correto, é preciso usar um lock para
      // cada conta.
    }
  }
}