using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Class2

{
  public class Ex2
  {
    public static void run()
    {
      // Imprima os números 1 - 1000 em uma thread, e os números 1001-2000 em
      // outra thread.
      // Use System.Threading.Task.
      // Quando ambas as threads terminarem, imprima "Pronto.".

    }
  }
}
