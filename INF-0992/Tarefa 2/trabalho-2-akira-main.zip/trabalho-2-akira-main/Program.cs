﻿using Class2;

Ex1.run();
Ex2.run();
Ex3.run();
Ex4.run();
Ex5.run();
