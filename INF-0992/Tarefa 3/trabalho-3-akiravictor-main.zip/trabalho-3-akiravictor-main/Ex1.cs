using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Class3
{

  class Expression { }

  class Number : Expression
  {
    double value;
    public Number(double _value) { value = _value; }
  }

  class BinaryOp : Expression
  {
    public Expression left;
    public Expression right;
    public BinaryOp(Expression l, Expression r)
    {
      left = l;
      right = r;
    }
  }
  class Addition : BinaryOp
  {
    public Addition(Expression l, Expression r) : base(l, r) { }
  }
  class Subtraction : BinaryOp
  {
    public Subtraction(Expression l, Expression r) : base(l, r) { }
  }
  class Multiplication : BinaryOp
  {
    public Multiplication(Expression l, Expression r) : base(l, r) { }
  }
  class Division : BinaryOp
  {
    public Division(Expression l, Expression r) : base(l, r) { }
  }
  class Negation : Expression
  {
    Expression value;
    public Negation(Expression v) { value = v; }
  }

  public class Ex1
  {
    public static void run()
    {
      // Implemente três Visitors que operem na árvore dada.
      // - O primeiro Visitor deve retornar a profundidade da árvore.
      // - O segundo deve retornar o resultado das operações.
      // - O terceiro deve gerar uma string com a árvore em forma de expressão matemática.

      // Por exemplo, para a árvore

      // ```
      // Addition(Number(1), Multiplication(Number(2), Number(3)))
      // ```

      // os resultados devem ser:

      // ```
      // Profundidade: 3
      // Resultado: 7
      // Expressão: (1 + (2 * 3))
      // ```

      // Não é necessário implementar a precedência de operações: use parênteses em todas
      // as operações binárias.

      // Imprima os resultados no console.

      Expression tree =
        new Addition(
          new Number(1),
          new Subtraction(
            new Number(5),
            new Negation(
              new Multiplication(
                new Number(-3),
                new Division(
                  new Number(10),
                  new Number(5)
                )
              )
            )
          )
        );

    }
  }
}