﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Class3.Calculator
{
    public abstract class Subscriber
    {

        public abstract void Update();
    }
}
