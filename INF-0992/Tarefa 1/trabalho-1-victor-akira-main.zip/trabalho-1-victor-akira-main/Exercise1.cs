using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Text;

namespace Class1
{
  public class Exercise1
  {
    public void run()
    {

      /*
        Leia os nomes dos arquivos no diretório `ex1data`,
        e escreva um por linha no arquivo `output/ex1output.txt`.
      */

      var directory_filepath = "./ex1data";
      var output_filepath = "output/ex1output.txt";

    }
  }
}
