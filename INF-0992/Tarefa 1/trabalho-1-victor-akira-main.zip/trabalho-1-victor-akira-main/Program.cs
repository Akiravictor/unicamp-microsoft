﻿using System.Text;
using Class1;

new Exercise1().run();
new Exercise2().run();
new Exercise3().run();